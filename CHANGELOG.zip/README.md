# Telamon

#### Description:
Telamon is an import of a classic mansion map from the game, ROBLOX. Beware, although the mansion may appear small on the exterior, it is a vast network of rooms. Those who explore them can end up walking away with higher valued scraps, but know you are also not the only salvagers... It's advised to play this with friends.

#### Difficulty: S (Similar to Rend)

![Telamon Image 1](https://i.imgur.com/6p6hQr6.jpg)

<details>
  <summary>Click to View More Images</summary>

  ![Telamon Image 2](https://i.imgur.com/WHvdkKL.jpg)

  ![Telamon Image 3](https://i.imgur.com/Ww0g8G8.jpg)

  ![Telamon Image 4](https://i.imgur.com/8CH6bIa.jpg)
</details>

## Features
- 3 Custom Scraps; 2 Custom Shovels!
- Loot Bugs can also be found salvaging!
- 2 hidden fire exits!
- Nostalgia!

## Credits
- Special credit to Shedletsky/Telamon for the creation of the original map.
- ROBLOX Studio

## Issues / Feedback
You can submit issues and feedback to my GitHub repository. You can also pull development builds here if you're up to bugs.
https://github.com/TofuBytesDEV/TelamonMoon/issues
